<html>

<head>
    <title>OLMS-Registration Form</title>
    <link href="https://fonts.googleapis.com/css?family=Bitter&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css'>
</head>

<body>
    <header>
        <nav>
            <div class="menu">
                <ul>
                    <li><a href="index.php">Back to home</a></li>
                </ul>
            </div>
        </nav>
    </header>
    <section>
        <div class="bg">

        </div>
        <div class="left-bg">

        </div>
        <div class="right-bg">
            <img src="image/register.svg">
        </div>
        <div class="mid-content">
            <form>
                <div class="form">
                    <h1>Registration Form</h1>
                    <div class="inputbox">
                        <input type="text" name="name" placeholder="Enter Your Name" required><br>
                        <input type="text" name="username" placeholder="Enter Username" required><br>
                        <input type="password" name="pwd" placeholder="Enter Password"><br>
                        <input type="password" name="cpwd" placeholder="Confirm Password"><br>
                        <font color="white">I am alredy register </font><a href="login.html"> click hear </a>
                        <button name="submit"> Sign up</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="foot">
            <font>© 2020 Online Library Management System | Designed by : Peeyush Itara , Gori Sharma</font>
        </div>
    </section>
</body>

</html>