<?php
include "include/header.php";
 ?>
    <section>
        <div class="bg">

        </div>
        <div class="left-bg">

        </div>
        <div class="right-bg">
            <img src="image/onlinebook.svg">
        </div>
        <div class="mid-content">
            <h2>Welcome in Online library management system</h2>
            <button><a href="login.php">Login</a></button>
        </div>

<?php
include "include/footer.php";
 ?>
